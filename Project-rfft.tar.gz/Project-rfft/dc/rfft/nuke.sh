\rm -rf *.log *.rpt *.rpt1 *.svf *.nl.v *.sdf alib-52 *.syn.*
