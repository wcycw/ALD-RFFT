dc_shell -64 -f rfft.tcl | tee rfft.log
