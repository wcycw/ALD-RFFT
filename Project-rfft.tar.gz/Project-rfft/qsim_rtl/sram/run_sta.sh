pt_shell -file memory_pt.tcl > memory_pt.log
