pt_shell -file rfft.tcl > rfft.log &
