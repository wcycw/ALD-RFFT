
# Simple script to run .m file in the command line
# MS 7/2015

matlab -nojvm -nodesktop -r lfsr1

